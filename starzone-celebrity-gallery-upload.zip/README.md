# StarZone Celebrity Gallery

A simple, responsive, no-build HTML photo gallery.

## Files
- `index.html` — the complete website.
- `images/` — add your own image files here.

## Add photos
1. Upload your image files into the `images` folder in this repository.
2. Open `index.html` and find `const photos = [...]`.
3. Add one entry per image, using the exact filename:

```js
const photos = [
  { name: "Celebrity Name", category: "Photos", image: "images/celebrity-01.jpg" },
  { name: "Another Name", category: "Events", image: "images/celebrity-02.jpg" }
];
```

4. Save/commit the changes. Open the GitHub Pages website to view it.

Use photos you own or have permission to publish. Keep image filenames simple (letters, numbers, hyphens).
